﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
//Natalie Eidt
public static class SaveAndLoad
{
    public static List<LevelData> savedGames = new List<LevelData>();
    //public static LevelData savedGame = new LevelData();
    public static string saveNameFolder = "ThisIsATest";
    public static bool saveExists = false;
    public static void Save()
    {
        UnityEngine.Debug.Log("Saving from SaveAndLoad");
        savedGames.Add(LevelData.current);

        //if directory doesn't exist yet, make one
        if(!File.Exists(Application.persistentDataPath + "/" + saveNameFolder))
        {
            Directory.CreateDirectory(Application.persistentDataPath + "/" + saveNameFolder);
            saveExists = true;
        }

        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/" + saveNameFolder + "/savedGames.txt");
        bf.Serialize(file, SaveAndLoad.savedGames);
        file.Close();
        
    }

    public static LevelData Load()
    {
        if(File.Exists(Application.persistentDataPath + "/" + saveNameFolder + "/savedGames.txt"))
        {
            UnityEngine.Debug.Log("Loading from file: " + Application.persistentDataPath + "/" + saveNameFolder + "/savedGames.txt");
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(Application.persistentDataPath + "/" + saveNameFolder + "/savedGames.txt", FileMode.Open);
            SaveAndLoad.savedGames = (List<LevelData>)bf.Deserialize(file);
            file.Close();
        }
        return (SaveAndLoad.savedGames[0]);
    }
}
