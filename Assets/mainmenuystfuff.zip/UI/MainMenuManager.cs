﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainMenuManager : MonoBehaviour
{
    public GameObject mainMenuCanvas;
    public GameObject howToMenuCanvas;
    public GameObject creditsCanvas;

    public SaveLoadController slcontrol;
    private void Start()
    {
        mainMenuCanvas.SetActive(true);
        howToMenuCanvas.SetActive(false);
    }

    public void _LoadGame()
    {
        mainMenuCanvas.SetActive(false);
        slcontrol.LoadLevel();
    }

    public void _StartNewGame()
    {
        mainMenuCanvas.SetActive(false);
        SceneManager.LoadScene(1);
    }

    public void ShowHowToMenu()
    {
        mainMenuCanvas.SetActive(false);
        howToMenuCanvas.SetActive(true);
    }
}